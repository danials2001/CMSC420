package pqueue.priorityqueues; // ******* <---  DO NOT ERASE THIS LINE!!!! *******

/* *****************************************************************************************
 * THE FOLLOWING IMPORTS ARE HERE ONLY TO MAKE THE JAVADOC AND iterator() METHOD SIGNATURE
 * "SEE" THE RELEVANT CLASSES. SOME OF THOSE IMPORTS MIGHT *NOT* BE NEEDED BY YOUR OWN
 * IMPLEMENTATION, AND IT IS COMPLETELY FINE TO ERASE THEM. THE CHOICE IS YOURS.
 * ********************************************************************************** */

import demos.GenericArrays;
import pqueue.exceptions.InvalidCapacityException;

import pqueue.exceptions.*;
import pqueue.fifoqueues.FIFOQueue;
import pqueue.heaps.ArrayMinHeap;
import java.util.*;

import javax.print.attribute.Size2DSyntax;
/**
 * <p>{@link LinearPriorityQueue} is a {@link PriorityQueue} implemented as a linear {@link java.util.Collection}
 * of common {@link FIFOQueue}s, where the {@link FIFOQueue}s themselves hold objects
 * with the same priority (in the order they were inserted).</p>
 *
 * <p>You  <b>must</b> implement the methods in this file! To receive <b>any credit</b> for the unit tests related to
 * this class, your implementation <b>must</b>  use <b>whichever</b> linear {@link Collection} you want (e.g
 * {@link ArrayList}, {@link LinkedList}, {@link java.util.Queue}), or even the various {@link List} and {@link FIFOQueue}
 * implementations that we provide for you. You can also use <b>raw</b> arrays, but take a look at {@link GenericArrays}
 * if you intend to do so. Note that, unlike {@link ArrayMinHeap}, we do not insist that you use a contiguous storage
 * {@link Collection}, but any one available (including {@link LinkedList}) </p>
 *
 * @param <T> The type held by the container.
 *
 * @author  ---- YOUR NAME HERE ----
 *
 * @see MinHeapPriorityQueue
 * @see PriorityQueue
 * @see GenericArrays
 */
public class LinearPriorityQueue<T> implements PriorityQueue<T> {

	/* ***********************************************************************************
	 * Write any private data elements or private methods for LinearPriorityQueue here...*
	 * ***********************************************************************************/
	
	private class Node {
	    T element;
	    // Lower values indicate higher priority
	    int priority;
	}

	private LinkedList<Node> data;
	protected boolean modificationFlag;


	/* *********************************************************************************************************
	 * Implement the following public methods. You should erase the throwings of UnimplementedMethodExceptions.*
	 ***********************************************************************************************************/

	/**
	 * Default constructor initializes the element structure with
	 * a default capacity. This default capacity will be the default capacity of the
	 * underlying element structure that you will choose to use to implement this class.
	 */
	public LinearPriorityQueue(){
		data = new LinkedList<>();
		modificationFlag = false;
	}

	/**
	 * Non-default constructor initializes the element structure with
	 * the provided capacity. This provided capacity will need to be passed to the default capacity
	 * of the underlying element structure that you will choose to use to implement this class.
	 * @see #LinearPriorityQueue()
	 * @param capacity The initial capacity to endow your inner implementation with.
	 * @throws InvalidCapacityException if the capacity provided is less than 1.
	 */
	public LinearPriorityQueue(int capacity) throws InvalidCapacityException{	// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (capacity < 1) {
			throw new InvalidCapacityException("Capacity < 1");
		}
		data = new LinkedList<>();
		modificationFlag = false;
	}

	@Override
	public void enqueue(T element, int priority) throws InvalidPriorityException{	// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (priority <= 0) {
			throw new InvalidPriorityException("Priority Invalid: " + priority);
		}
		
		Node n = new Node();
		n.element = element;
		n.priority = priority;
		int size = size();
		
		if (isEmpty()) {
			data.add(n);
			return;
		}
		
		for (int i = 0; i < size; i++) {
			if (data.get(i).priority > priority) {
				data.add(i, n);
				break;
			} else if (i == size()-1) {
				data.addLast(n);
			}
		}
		modificationFlag = true;
	}

	@Override
	public T dequeue() throws EmptyPriorityQueueException { 	// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (isEmpty()) {
			throw new EmptyPriorityQueueException("Queue is empty");
		}
		Node n = data.removeFirst();
		modificationFlag = true;

		return n.element;
	}

	@Override
	public T getFirst() throws EmptyPriorityQueueException {	// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (isEmpty()) {
			throw new EmptyPriorityQueueException("Queue is empty");
		}
		Node n = data.getFirst();
		return n.element;
	}

	@Override
	public int size() {
		return isEmpty() ? 0 : data.size();
	}

	@Override
	public boolean isEmpty() {
		return data != null ? data.size() == 0 : false; 
	}


	@Override
	public Iterator<T> iterator() {
		modificationFlag = false;
		Iterator<T> it = new Iterator<T>() {

			private int currentIndex = 0;

            @Override
            public boolean hasNext() {
            	return currentIndex < data.size() && data.get(currentIndex) != null;
            }

            @Override
            public T next() {
            	if(modificationFlag)
    				throw new ConcurrentModificationException("next(): Attempted to traverse a list after removal.");
    			Node n = data.get(currentIndex++);
    			return n.element;
            }

        };
        return it;
	}

}