package phonebook.hashes;

import phonebook.exceptions.UnimplementedMethodException;
import phonebook.utils.KVPair;
import phonebook.utils.PrimeGenerator;
import phonebook.utils.Probes;

/**
 * <p>{@link QuadraticProbingHashTable} is an Openly Addressed {@link HashTable} which uses <b>Quadratic
 * Probing</b> as its collision resolution strategy. Quadratic Probing differs from <b>Linear</b> Probing
 * in that collisions are resolved by taking &quot; jumps &quot; on the hash table, the length of which
 * determined by an increasing polynomial factor. For example, during a key insertion which generates
 * several collisions, the first collision will be resolved by moving 1^2 + 1 = 2 positions over from
 * the originally hashed address (like Linear Probing), the second one will be resolved by moving
 * 2^2 + 2= 6 positions over from our hashed address, the third one by moving 3^2 + 3 = 12 positions over, etc.
 * </p>
 *
 * <p>By using this collision resolution technique, {@link QuadraticProbingHashTable} aims to get rid of the
 * &quot;key clustering &quot; problem that {@link LinearProbingHashTable} suffers from. Leaving more
 * space in between memory probes allows other keys to be inserted without many collisions. The tradeoff
 * is that, in doing so, {@link QuadraticProbingHashTable} sacrifices <em>cache locality</em>.</p>
 *
 * @author YOUR NAME HERE!
 *
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see OrderedLinearProbingHashTable
 * @see LinearProbingHashTable
 * @see CollisionResolver
 */
public class QuadraticProbingHashTable extends OpenAddressingHashTable {

    /* ********************************************************************/
    /* ** INSERT ANY PRIVATE METHODS OR FIELDS YOU WANT TO USE HERE: ******/
    /* ********************************************************************/
	private int tombstoneCount = 0;

    /* ******************************************/
    /*  IMPLEMENT THE FOLLOWING PUBLIC METHODS: */
    /* **************************************** */

    /**
     * Constructor with soft deletion option. Initializes the internal storage with a size equal to the starting value of  {@link PrimeGenerator}.
     * @param soft A boolean indicator of whether we want to use soft deletion or not. {@code true} if and only if
     *               we want soft deletion, {@code false} otherwise.
     */
    public QuadraticProbingHashTable(boolean soft) {
    	softFlag = soft;
    	primeGenerator = new PrimeGenerator();
    	table = new KVPair[primeGenerator.getCurrPrime()];
    }

    @Override
    public Probes put(String key, String value) {
    	if (key == null || value == null) {
    		throw new IllegalArgumentException("null key and/or value");
    	}
    	
    	int probes = 0;
    	
    	// resize
    	if ((double)(count + tombstoneCount)/capacity() > .5) {
    		int new_capacity = primeGenerator.getNextPrime();
    		KVPair[] old_table = table;
    		table = new KVPair[new_capacity];
    		for (KVPair kv : old_table) {
    			probes++;
    			// reinsert all nodes in old table
    			if (kv != null && !kv.equals(TOMBSTONE)) {
    				int hash = hash(kv.getKey());
    				int quad_iter = 1; 
    				while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2))% new_capacity] != null) {
    					quad_iter++;
    					probes++;
    				}
    				probes++;
    				table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % new_capacity] = kv;
    			}
    		}
        	tombstoneCount = 0;
    	}
    	
    	// insert new node
    	int hash = hash(key);
		int quad_iter = 1; 
		if (key.equals("Yi"))
    		System.out.println("QP: " + key + " hashes to " + hash);
		//System.out.println("Key=" + key + " hashes to " + hash);

    	while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % capacity()] != null/* && !table[(hash + (quad_iter-1) + (quad_iter-1)^2) %capacity()].equals(TOMBSTONE)*/) {
			quad_iter++;
    		probes++;
    	}
    	/* if (table[(hash + (quad_iter-1) + (quad_iter-1)^2 %capacity())] != null && table[(hash+ (quad_iter-1) + (quad_iter-1)^2 %capacity())].equals(TOMBSTONE)) {
    		tombstoneCount--;
    	} */
		//System.out.println("Entering " + key + " in index " + (hash+ (quad_iter-1) + (int)Math.pow(quad_iter-1,2))%capacity());
		//System.out.println((quad_iter-1) + (int)Math.pow(quad_iter-1,2));
    	table[(hash+ (quad_iter-1) + (int)Math.pow(quad_iter-1,2))%capacity()] = new KVPair(key, value);
    	if (key.equals("Yi"))
    		System.out.println("QP: " + key + ", " + value+ " inserted at " + hash%capacity());
    	probes++;
    	count++;
    	
    	return new Probes(value, probes);
    }


    @Override
    public Probes get(String key) {
    	if (key == null) {
    		return new Probes(null, 0);
    	}
    	
    	int probes = 1;
    	int hash = hash(key);
    	Probes p = null;
    	int quad_iter = 1;
    	
    	while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2) %capacity())] != null) {
    		if (table[(hash+ (quad_iter-1) + (int)Math.pow(quad_iter-1,2) %capacity())].getKey().equals(key)) {
    			p = new Probes(table[(hash+ (quad_iter-1) + (int)Math.pow(quad_iter-1,2) %capacity())].getValue(), probes);
    			if (key.equals("Yi")) {
    				System.out.println(this.toString());
    	    		System.out.println("QP: " + key + ", " + table[hash%capacity()].getValue() + " found at " + hash%capacity());
    			}
    			break;
    		}
    		probes++;
    		quad_iter++;
    	}
    	
    	if (p == null) {
    		return new Probes(null, probes);
    	}
    	return p;
    }

    @Override
    public Probes remove(String key) {
    	// first step for both hard and soft is to find kv, iterate through till found (or null reached)
    	int probes = 1;
    	int hash = hash(key);
    	boolean found = false;
    	String value = null;
    	int quad_iter = 1;
    	
    	while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) %capacity()] != null) {
    		if (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) %capacity()].getKey().equals(key)) {
    			value = table[hash%capacity()].getValue();
    			found = true;
    			// if soft we can just make it a tombstone here
    			if (softFlag) {
    				tombstoneCount++;
    				count--;
    				table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) %capacity()] = TOMBSTONE;
    				return new Probes(value, probes);
    			}
    			break;
    		}
    		probes++;
    		quad_iter++;
    	}
    	if (!found) {
    		return new Probes(null, probes);
    	}
    	
    	// hard delete value
    	table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) %capacity()] = null;
    	count--;
    	//probes++;
    	
    	// hard deletion reinserting EVERYTHING
    	// create new table of same capacity size and just reinsert everyting
    	
    	KVPair[] old_table = table;
    	table = new KVPair[capacity()];
    	for (KVPair kv : old_table) {
    		probes++;
    		if (kv != null) {
    			quad_iter = 1;
    			hash = hash(kv.getKey());
    			while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % capacity()] != null) {
					quad_iter++;
					probes++;
				}
    			probes++;
				table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % capacity()] = kv;
    		}
    	}
    	
    	return new Probes(value, probes);
    }


    @Override
    public boolean containsKey(String key) {
    	int hash = hash(key);
    	int quad_iter = 1;
    	
    	while (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % capacity()] != null) {
    		if (table[(hash + (quad_iter-1) + (int)Math.pow(quad_iter-1,2)) % capacity()].getKey().equals(key)) {
    			return true;
    		}
    		quad_iter++;
    	}
    	return false;
    }

    @Override
    public boolean containsValue(String value) {
    	for (KVPair kv : table) {
    		if (kv != null && kv.getValue().equals(value)) {
    			return true;
    		}
    	}
    	return false;
    }
    @Override
    public int size(){
    	return count;
    }

    @Override
    public int capacity() {
    	return table.length;
    }

}