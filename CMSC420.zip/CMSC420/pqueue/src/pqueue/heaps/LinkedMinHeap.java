package pqueue.heaps; // ******* <---  DO NOT ERASE THIS LINE!!!! *******

import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;

/* *****************************************************************************************
 * THE FOLLOWING IMPORT IS NECESSARY FOR THE ITERATOR() METHOD'S SIGNATURE. FOR THIS
 * REASON, YOU SHOULD NOT ERASE IT! YOUR CODE WILL BE UNCOMPILABLE IF YOU DO!
 * ********************************************************************************** */

import java.util.Iterator;

import pqueue.exceptions.UnimplementedMethodException;

/**
 * <p>A {@link LinkedMinHeap} is a tree (specifically, a <b>complete</b> binary tree) where every node is
 * smaller than or equal to its descendants (as defined by the {@link Comparable#compareTo(Object)} overridings of the type T).
 * Percolation is employed when the root is deleted, and insertions guarantee maintenance of the heap property in logarithmic time. </p>
 *
 * <p>You <b>must</b> edit this class! To receive <b>any</b> credit for the unit tests related to this class,
 * your implementation <b>must</b> be a &quot;linked&quot;, <b>non-contiguous storage</b> implementation based on a
 * binary tree of nodes and references. Use the skeleton code we have provided to your advantage, but always remember
 * that the only functionality our tests can test is {@code public} functionality.</p>
 * 
 * @author --- YOUR NAME HERE! ---
 *
 * @param <T> The {@link Comparable} type of object held by {@code this}.
 *
 * @see MinHeap
 * @see ArrayMinHeap
 */
public class LinkedMinHeap<T extends Comparable<T>> implements MinHeap<T> {

	/* ***********************************************************************
	 * An inner class representing a minheap's node. YOU *SHOULD* BUILD YOUR *
	 * IMPLEMENTATION ON TOP OF THIS CLASS!                                  *
 	 * ********************************************************************* */
	private class MinHeapNode {
		private T data;
		private MinHeapNode lChild, rChild;
		private MinHeapNode Parent;
		private boolean isLeftChild;

        /* *******************************************************************
         * Write any further data elements or methods for MinHeapNode here...*
         ********************************************************************* */

	}

	/* *********************************
	  * Root of your tree: DO NOT ERASE!
	  * *********************************
	 */
	private MinHeapNode root;




    /* *********************************************************************************** *
     * Write any further private data elements or private methods for LinkedMinHeap here...*
     * *************************************************************************************/
	private int size = 0;
	protected boolean modificationFlag;
	
	public static int log2(int n)
    {
        int ret  = (int)(Math.log(n) / Math.log(2));
        return ret;
    }

	private MinHeapNode getLastParentNode() {
		int pos = size+1;
		int level = log2(pos);
		int level_size = (int)Math.pow(2, level);
		int numFromRight = pos - level_size;
		
		MinHeapNode curr = root;
		
		while (curr != null && curr.lChild != null && curr.rChild != null) {
			if (numFromRight < level_size/2) {
				curr = curr.lChild;
			} else {
				curr = curr.rChild;
			}
			numFromRight %= level_size;
			level_size /= 2;
		}
		
		return curr;
	}
	
	private MinHeapNode getLastNode() {
		int level = log2(size);
		int level_size = (int)Math.pow(2, level);
		int numFromRight = size - level_size;
		MinHeapNode curr = root;
		int i = 0;
		while (curr != null && i < level && level_size > 0) {
			if (numFromRight < level_size/2) {
				curr = curr.lChild;
			} else {
				curr = curr.rChild;
			}
			level_size /= 2;
			numFromRight %= level_size;
			i++;
		}
		return curr;
	}
	
	private MinHeapNode swapWithParent(MinHeapNode child) {
		T element = child.data;
		child.data = child.Parent.data;
		child.Parent.data = element;
		return child.Parent;
	}
	
	private MinHeapNode swapEndWithRoot() {
		MinHeapNode last = getLastNode();
		T element = last.data;
		last.data = root.data;
		root.data = element;
		
		return last;
	}
	
	private MinHeapNode swapWithChild(MinHeapNode parent, boolean leftChild) {
		MinHeapNode child;
		if (leftChild) {
			T temp = parent.data;
			parent.data = parent.lChild.data;
			parent.lChild.data = temp;
			child = parent.lChild;
		} else {
			T temp = parent.data;
			parent.data = parent.rChild.data;
			parent.rChild.data = temp;
			child = parent.rChild;
		}
		return child;
	}
	
	private void collectNodes(MinHeapNode curr, ArrayList<T> collect) {
		if (curr != null) {
			collect.add(curr.data);
			collectNodes(curr.lChild, collect);
			collectNodes(curr.rChild, collect);
		}
	}
	
	
    /* *********************************************************************************************************
     * Implement the following public methods. You should erase the throwings of UnimplementedMethodExceptions.*
     ***********************************************************************************************************/

	/**
	 * Default constructor.
	 */
	public LinkedMinHeap() {
		root = null;
		modificationFlag = false;
	}

	/**
	 * Second constructor initializes {@code this} with the provided element.
	 *
	 * @param rootElement the data to create the root with.
	 */
	public LinkedMinHeap(T rootElement) {
		root = new MinHeapNode();
		root.data = rootElement;
		size++;
		modificationFlag = false;
	}

	/**
	 * Copy constructor initializes {@code this} as a carbon
	 * copy of the parameter, which is of the general type {@link MinHeap}!
	 * Since {@link MinHeap} is an {@link Iterable} type, we can access all
	 * of its elements in proper order and insert them into {@code this}.
	 *
	 * @param other The {@link MinHeap} to copy the elements from.
	 */
	public LinkedMinHeap(MinHeap<T> other) {
		this();
		Iterator<T> it = other.iterator();
		while (it.hasNext()) {
			insert(it.next());
		}
	}


    /**
     * Standard {@code equals} method. We provide this for you. DO NOT EDIT!
     * You should notice how the existence of an {@link Iterator} for {@link MinHeap}
     * allows us to access the elements of the argument reference. This should give you ideas
     * for {@link #LinkedMinHeap(MinHeap)}.
     * @return {@code true} If the parameter {@code Object} and the current MinHeap
     * are identical Objects.
     *
     * @see Object#equals(Object)
     * @see #LinkedMinHeap(MinHeap)
     */
	/**
	 * Standard equals() method.
	 *
	 * @return {@code true} If the parameter Object and the current MinHeap
	 * are identical Objects.
	 */
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof MinHeap))
			return false;
		Iterator itThis = iterator();
		Iterator itOther = ((MinHeap) other).iterator();
		while (itThis.hasNext())
			if (!itThis.next().equals(itOther.next()))
				return false;
		return !itOther.hasNext();
	}

	@Override
	public boolean isEmpty() {
		if (root == null || root.data == null) {
			return true;
		}
		return false;
	}

	@Override
	public int size() {
		return size;
	}


	@Override
	public void insert(T element) {
		MinHeapNode parent = null;
		try {
			parent = getLastParentNode();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
		MinHeapNode temp = new MinHeapNode();
		temp.data = element;
		temp.Parent = parent;
		// if there is no parent (just root)
		if (parent == null) {
			root = temp;
			size++;
			modificationFlag = true;
			return;
		} else if (parent.lChild == null) {
			temp.isLeftChild = true;
			parent.lChild = temp;
		} else {
			temp.isLeftChild = false;
			parent.rChild = temp;
		}
		while (temp.Parent != null && temp.data.compareTo(temp.Parent.data) < 0) {
			temp = swapWithParent(temp);
		}
		size++;
		modificationFlag = true;
	}

	@Override
	public T getMin() throws EmptyHeapException {		// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (isEmpty()) {
			throw new EmptyHeapException("GetMin: Empty heap");
		}
		return root.data;
	}

	@Override
	public T deleteMin() throws EmptyHeapException {    // DO *NOT* ERASE THE "THROWS" DECLARATION!
		T ret = getMin();
		if (size == 1) {
			root = null;
			size--;
			return ret;
		}
		
		//replace root node with last node
		MinHeapNode last = swapEndWithRoot();
		
		//remove pointers to last node
		if (last.isLeftChild) {
			last.Parent.lChild = null;
		} else {
			last.Parent.rChild = null;
		}

		//percolate down
		
		MinHeapNode curr = root;
		while (true) {
			boolean right = true;
			if (curr.lChild == null) {
				break;
			} else if (curr.rChild == null) {
				right = false;
			}
			boolean childToSwapLeft;
			if (right && curr.lChild.data.compareTo(curr.rChild.data) > 0) {
				childToSwapLeft = false;
			} else {
				childToSwapLeft = true;
			}
			if ((childToSwapLeft && curr.data.compareTo(curr.lChild.data) > 0) || (!childToSwapLeft && curr.data.compareTo(curr.rChild.data) > 0)) {
				curr = swapWithChild(curr, childToSwapLeft);
			} else {
				break;
			}
		}
		
		size--;
		modificationFlag = true;
		return ret;
	}

	//look up BFS option?
	@Override
	public Iterator<T> iterator() {
		modificationFlag = false;
		ArrayList<T> store = new ArrayList<T>();
		collectNodes(root, store);
		Collections.sort(store);
		Iterator<T> it = new Iterator<T>() {

			private int currentIndex = 0;
			

            @Override
            public boolean hasNext() {
            	return currentIndex < size && store.get(currentIndex) != null;
            }

            @Override
            public T next() {
            	if(modificationFlag)
    				throw new ConcurrentModificationException("next(): Attempted to traverse a list after removal.");
    			return store.get(currentIndex++);
            }

        };
        return it;	
	}

}
