package avlg;

import avlg.exceptions.UnimplementedMethodException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import avlg.exceptions.EmptyTreeException;
import avlg.exceptions.InvalidBalanceException;

/** <p>{@link AVLGTree}  is a class representing an <a href="https://en.wikipedia.org/wiki/AVL_tree">AVL Tree</a> with
 * a relaxed balance condition. Its constructor receives a strictly  positive parameter which controls the <b>maximum</b>
 * imbalance allowed on any subtree of the tree which it creates. So, for example:</p>
 *  <ul>
 *      <li>An AVL-1 tree is a classic AVL tree, which only allows for perfectly balanced binary
 *      subtrees (imbalance of 0 everywhere), or subtrees with a maximum imbalance of 1 (somewhere). </li>
 *      <li>An AVL-2 tree relaxes the criteria of AVL-1 trees, by also allowing for subtrees
 *      that have an imbalance of 2.</li>
 *      <li>AVL-3 trees allow an imbalance of 3.</li>
 *      <li>...</li>
 *  </ul>
 *
 *  <p>The idea behind AVL-G trees is that rotations cost time, so maybe we would be willing to
 *  accept bad search performance now and then if it would mean less rotations. On the other hand, increasing
 *  the balance parameter also means that we will be making <b>insertions</b> faster.</p>
 *
 * @author YOUR NAME HERE!
 *
 * @see EmptyTreeException
 * @see InvalidBalanceException
 * @see StudentTests
 */
public class AVLGTree<T extends Comparable<T>> {

    /* ********************************************************* *
     * Write any private data elements or private methods here...*
     * ********************************************************* */

	private class Node {
		private T data;
		private Node left, right;
		private Node Parent;
		private int height;
		
		private int replsucc_flag = 0;
		
		public Node(T data) {
			this.data = data;
			height = 0;
		}

        /* *******************************************************************
         * Write any further data elements or methods for MinHeapNode here...*
         ********************************************************************* */

	}
	
	private int height(Node n) {
		if (n == null) {
			return -1;
		}
		int h = 1+Math.max(height(n.left), height(n.right));
		n.height = h;
		return h;
	}
	
	private int balance(Node n) {
		if (n != null) {
			return height(n.left) - height(n.right);
		}
		return 0;
	}
	
	private Node rotateRight(Node n) {
		Node temp = n.left;
		n.left = temp.right;
		temp.right = n;
		//parents
		temp.Parent = n.Parent;
		n.Parent = temp;
		if (n.left != null) {
			n.left.Parent = n;
		}
		return temp;
	}
	
	private Node rotateLeft(Node n) {
		Node temp = n.right;
		n.right = temp.left;
		temp.left = n;
		//parents
		temp.Parent = n.Parent;
		n.Parent = temp;
		if (n.right != null) {
			n.right.Parent = n;
		}
		return temp;
	}
	
	private Node rotateLeftRight(Node n) {
		n.left = rotateLeft(n.left);
		n = rotateRight(n);
		return n;
	}
	
	private Node rotateRightLeft(Node n) {
		n.right = rotateRight(n.right);
		n = rotateLeft(n);
		return n;
	}
	
	
	private Node root;
	private int G;
	private int balance = 0;

    /* ******************************************************** *
     * ************************ PUBLIC METHODS **************** *
     * ******************************************************** */

    /**
     * The class constructor provides the tree with the maximum imbalance allowed.
     * @param maxImbalance The maximum imbalance allowed by the AVL-G Tree.
     * @throws InvalidBalanceException if maxImbalance is a value smaller than 1.
     */
    public AVLGTree(int maxImbalance) throws InvalidBalanceException {
    	if (maxImbalance < 1) {
    		throw new InvalidBalanceException("maxImbalance < 1");
    	}
    	G = maxImbalance+1;
    }

    /**
     * Insert key in the tree. You will <b>not</b> be tested on
     * duplicates! This means that in a deletion test, any key that has been
     * inserted and subsequently deleted should <b>not</b> be found in the tree!
     * s
     * @param key The key to insert in the tree.
     */
    public void insert(T key) {
    	root = insertAux(key, root);
    	updateParents(root, null);
    }
    
    private void updateParents(Node curr, Node parent) {
    	if (curr != null) {
    		curr.Parent = parent;
    		updateParents(curr.left, curr);
    		updateParents(curr.right, curr);
    	}
    }
    
    private Node insertAux(T key, Node n) {
    	if (n == null) {
    		return new Node(key);
    	}
    	if (key.compareTo(n.data) < 0) {
    		n.left = insertAux(key, n.left);
    		if (balance(n) == G) {
    			if (key.compareTo(n.left.data) < 0) {
    				n = rotateRight(n);
    			} else {
    				n = rotateLeftRight(n);
    			}
    		}
    		height(n);
    	} else {
    		n.right = insertAux(key, n.right);
    		if (balance(n) == -G) {
    			if (key.compareTo(n.right.data) > 0) {
    				n = rotateLeft(n);
    			} else {
    				n = rotateRightLeft(n);
    			}
    		}
    		height(n);
    	}
    	return n;
    }
    
    private void rmAux(Node root) {
    	if (root == null) {
    		return;
    	}
    	root.replsucc_flag = 0;
    	rmAux(root.left);
    	rmAux(root.right);
    }
    
    
    /**
     * Delete the key from the data structure and return it to the caller.
     * @param key The key to delete from the structure.
     * @return The key that was removed, or {@code null} if the key was not found.
     * @throws EmptyTreeException if the tree is empty.
     */
    public T delete(T key) throws EmptyTreeException {
    	if (isEmpty()) {
    		throw new EmptyTreeException("deleting from empty tree");
    	}
    	
    	Node toDelete = searchNode(key);
    	rmAux(root);
    	
    	if (toDelete == null) {
    		return null;
    	}
    	if (getCount() == 1) {
    		clear();
    		return key;
    	}
    	if (toDelete.left == null && toDelete.right == null) {
    		if (key.compareTo(toDelete.Parent.data) < 0) {
    			toDelete.Parent.left = null;
    		} else {
    			toDelete.Parent.right = null;
    		}
    		toDelete = toDelete.Parent;
    	}
    	// case with 1 tail where node can be collapsed
    	else if ((toDelete.left == null || toDelete.right == null)) {
    		if (toDelete.Parent == null) {
    			if (toDelete.right != null) {
    				toDelete = toDelete.right;
    			} else {
    				toDelete = toDelete.left;
    			}
    			toDelete.Parent = null;
    			root = toDelete;
    		}
    		else if (toDelete.right != null) {
    			if (key.compareTo(toDelete.Parent.data) < 0) {
    				toDelete.Parent.left = toDelete.right;
    			} else {
    				toDelete.Parent.right = toDelete.right;
    			}
					toDelete.right.Parent = toDelete.Parent;
    		}
    		else {
    			if (key.compareTo(toDelete.Parent.data) > 0) {
    				toDelete.Parent.right = toDelete.left;
    			} else {
    				toDelete.Parent.left = toDelete.left;
    			}
					toDelete.left.Parent = toDelete.Parent;
    		}
    		toDelete = toDelete.Parent;
    	} else { // finding next successor
    		/*Node succ = findSuccessor(toDelete);
    		if (succ.data.compareTo(succ.Parent.data) > 0) {
        		succ.Parent.right = null;
    		} else {
    			succ.Parent.left = null;
    		}
    		
    		toDelete.data = succ.data;
    		toDelete = succ.Parent; */
    		
    		Node succ = findSuccessor(toDelete);
    		toDelete.data = succ.data;
    		toDelete.replsucc_flag = 1;
    		return delete(toDelete.data);
    	}
    	height(root);
    	//check balance from deleted node upwards
    	//TODO: maybe check from successor's parent? 
    	while (toDelete != null) {
    		
    		toDelete = checkUpBalance(toDelete);
        	// if point where unbalanced, use rotations to rebalance
        	if (toDelete != null) {
        		//rotate depending on "what rotation is right for us" using toDelete as starting point
        		Node dpar = toDelete.Parent;
        		if (balance(toDelete) >= G) {
        			if (toDelete.left != null) {
        				if (balance(toDelete.left) >= 0) {
            				toDelete = rotateRight(toDelete);
            			} else {
            				toDelete = rotateLeftRight(toDelete);
            			}
        			}
        		} else if (balance(toDelete) <= -G) {
        			if (toDelete.right != null) {
        				if (balance(toDelete.right) > 0) {
        					toDelete = rotateRightLeft(toDelete);
        				} else {
        					toDelete = rotateLeft(toDelete);
        				}
        			}
        		}
        		// add todelete pointer back to main root pointer tree
        		if (dpar != null) {
        			if (dpar.data.compareTo(toDelete.data) < 0) {
        				dpar.right = toDelete;
        			} else {
        				dpar.left = toDelete;
        			}
        		} else {
        			root = toDelete;
        		}
        	}
    	}
    	
    	return key;
    }
    
    private Node findSuccessor(Node n) {
    	Node curr = n.right;
    	while (curr.left != null) {
    		curr = curr.left;
    	} return curr;
    }
    
    private Node checkUpBalance(Node n) {
    	while (n != null && Math.abs(balance(n)) < G) {
    		if (n.Parent == null) {
    			root = n;
    		}
    		n = n.Parent;
    	}
    	return n;
    }

    /**
     * <p>Search for key in the tree. Return a reference to it if it's in there,
     * or {@code null} otherwise.</p>
     * @param key The key to search for.
     * @return key if key is in the tree, or {@code null} otherwise.
     * @throws EmptyTreeException if the tree is empty.
     */
    public T search(T key) throws EmptyTreeException {
    	Node found = searchNode(key);
    	return found != null ? found.data : null;
    }
    
    public Node searchNode(T key) throws EmptyTreeException {
    	if (isEmpty())
    		throw new EmptyTreeException("searching empty tree");
    	
    	Node curr = root;
    	while (curr != null) {
    		if (curr.data.equals(key)) {
    			if (curr.replsucc_flag != 0) {
    				curr = curr.right;
    				continue;
    			}
    			return curr;
    		} else if (key.compareTo(curr.data) < 0) {
    			curr = curr.left;
    		} else { 
    			curr = curr.right;
    		}
    	}
    	
    	return null;
    }

    /**
     * Retrieves the maximum imbalance parameter.
     * @return The maximum imbalance parameter provided as a constructor parameter.
     */
    public int getMaxImbalance(){
    	return G-1;
    }


    /**
     * <p>Return the height of the tree. The height of the tree is defined as the length of the
     * longest path between the root and the leaf level. By definition of path length, a
     * stub tree has a height of 0, and we define an empty tree to have a height of -1.</p>
     * @return The height of the tree. If the tree is empty, returns -1.
     */
    public int getHeight() {
    	return height(root);
    }

    /**
     * Query the tree for emptiness. A tree is empty iff it has zero keys stored.
     * @return {@code true} if the tree is empty, {@code false} otherwise.
     */
    public boolean isEmpty() {
    	return root == null ? true : false;
    }

    /**
     * Return the key at the tree's root node.
     * @return The key at the tree's root node.
     * @throws  EmptyTreeException if the tree is empty.
     */
    public T getRoot() throws EmptyTreeException{
    	if (isEmpty())
    		throw new EmptyTreeException("getting root from empty tree");
    	return root.data;
    }


    /**
     * <p>Establishes whether the AVL-G tree <em>globally</em> satisfies the BST condition. This method is
     * <b>terrifically useful for testing!</b></p>
     * @return {@code true} if the tree satisfies the Binary Search Tree property,
     * {@code false} otherwise.
     */
    public boolean isBST() {
    	if (isEmpty()) {
    		return true;
    	}
    	return bstAux(root);
    }
    
    //fix?
    public boolean bstAux(Node n) {
    	if (n.left == null && n.right == null) {
    		return true;
    	}
    	
    	if (n.left != null) {
    		if (n.data.compareTo(n.left.data) >= 0) {
    			return bstAux(n.left);
    		} else {
    			return false;
    		}
    	}
    	
    	if (n.right != null) {
    		if (n.data.compareTo(n.right.data) <= 0) {
    			return bstAux(n.right);
    		} else {
    			return false;
    		}
    	}
    	return false;
    }


    /**
     * <p>Establishes whether the AVL-G tree <em>globally</em> satisfies the AVL-G condition. This method is
     * <b>terrifically useful for testing!</b></p>
     * @return {@code true} if the tree satisfies the balance requirements of an AVLG tree, {@code false}
     * otherwise.
     */
    public boolean isAVLGBalanced() {
    	height(root);
    	return avlgBalancedAux(root);
    }
    
    private boolean avlgBalancedAux(Node n) {
    	if (n == null) {
    		return true;
    	}
    	
    	if (Math.abs(balance(n)) >= G) {
    		return false;
    	}
    	
    	return avlgBalancedAux(n.left) && avlgBalancedAux(n.right);
    	
    }

    /**
     * <p>Empties the AVL-G Tree of all its elements. After a call to this method, the
     * tree should have <b>0</b> elements.</p>
     */
    public void clear(){
    	root = null;
    }


    /**
     * <p>Return the number of elements in the tree.</p>
     * @return  The number of elements in the tree.
     */
    public int getCount(){
    	return countAux(root);
    }
    
    private int countAux(Node n) {
    	if (n == null)
    		return 0;
    	return 1+countAux(n.left)+countAux(n.right);
    }
    


    }


