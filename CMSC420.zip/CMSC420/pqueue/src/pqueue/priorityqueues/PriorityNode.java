package pqueue.priorityqueues;

public class PriorityNode<T> implements Comparable<PriorityNode<T>> {
    T element;
    // Lower values indicate higher priority
    int priority;
    int id;
    static int age = 0;
    
    public PriorityNode(T element, int priority) {
    	this.element = element;
    	this.priority = priority;
    	id = age;
    	age++;
    }

	@Override
	public int compareTo(PriorityNode<T> o) {
		if (this.priority == o.priority) {
			return this.id - o.id;
		}
		return this.priority - o.priority;
	}
	
}
