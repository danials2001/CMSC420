package bpt;

import bpt.UnimplementedMethodException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * <p>{@code BinaryPatriciaTrie} is a Patricia Trie over the binary alphabet &#123;	 0, 1 &#125;. By restricting themselves
 * to this small but terrifically useful alphabet, Binary Patricia Tries combine all the positive
 * aspects of Patricia Tries while shedding the storage cost typically associated with tries that
 * deal with huge alphabets.</p>
 *
 * @author YOUR NAME HERE!
 */
public class BinaryPatriciaTrie {

    /* We are giving you this class as an example of what your inner node might look like.
     * If you would prefer to use a size-2 array or hold other things in your nodes, please feel free
     * to do so. We can *guarantee* that a *correct* implementation exists with *exactly* this data
     * stored in the nodes.
     */
    private static class TrieNode {
        private TrieNode left, right;
        private String str;
        private boolean isKey;

        // Default constructor for your inner nodes.
        TrieNode() {
            this("", false);
        }

        // Non-default constructor.
        TrieNode(String str, boolean isKey) {
            left = right = null;
            this.str = str;
            this.isKey = isKey;
        }
    }

    private TrieNode root;
    private int count = 0;

    /**
     * Simple constructor that will initialize the internals of {@code this}.
     */
    public BinaryPatriciaTrie() {
    	root = new TrieNode();
    }

    /**
     * Searches the trie for a given key.
     *
     * @param key The input {@link String} key.
     * @return {@code true} if and only if key is in the trie, {@code false} otherwise.
     */
    public boolean search(String key) {
    	return searchAux(key) != null;
    }
    
    // returns node where string is found, if not found return null
    public TrieNode searchAux(String key) {
    	TrieNode curr = root;
    	/*if (key.charAt(0) == '0') {
    		curr = curr.left;
    	} else {
    		curr = curr.right;
    	} */
    	
    	while (curr != null) {
    		if (key.length() >= curr.str.length() && key.substring(0,curr.str.length()).equals(curr.str)) {
    			key = key.substring(curr.str.length());
    		} else {
    			return null;
    		}
    		
    		if (key.isEmpty()) {
    			if (curr.isKey) {
    				return curr;
    			} else {
    				return null;
    			}
    		}
    		
    		if (key.charAt(0) == '0') {
        		curr = curr.left;
        	} else {
        		curr = curr.right;
        	}
    	}
    	
    	return null;
    }

    /**
     * Inserts key into the trie.
     *
     * @param key The input {@link String}  key.
     * @return {@code true} if and only if the key was not already in the trie, {@code false} otherwise.
     */
    public boolean insert(String key) {
    	TrieNode curr = root;
    	
    	TrieNode parent = null;
    	// search through it
    	while (curr != null) {
    		if (key.length() >= curr.str.length() && key.substring(0,curr.str.length()).equals(curr.str)) {
    			key = key.substring(curr.str.length());
    		} else {
    			break;
    		}
    		
    		if (key.isEmpty()) {
    			if (curr.isKey) {
    				return false;
    			} else {
    				// flip bit
    				curr.isKey = true;
    				count++;
    				return true;
    			}
    		}
    		
    		parent = curr;
    		if (key.charAt(0) == '0') {
        		curr = curr.left;
        	} else {
        		curr = curr.right;
        	}
    	}
    	
    	// parent node key is prefix of insertion key
    	if (curr == null) {
    		if (key.charAt(0) == '0') {
        		parent.left = new TrieNode(key, true);
        	} else {
        		parent.right = new TrieNode(key, true);
        	}
    		count++;
    		return true;
    	}
    	
    	if (curr != null) {
    		// insertion key is prefix of current node key
    		if (key.length() <= curr.str.length() && curr.str.substring(0,key.length()).equals(key)) {
    			String new_parent_key = curr.str.substring(0,key.length());
    			// key becomes child key
    			key = curr.str.substring(key.length());
    			TrieNode child = new TrieNode(key, curr.isKey);
    			child.left = curr.left;
    			child.right = curr.right;
    			
    			curr.str = new_parent_key;
    			if (key.charAt(0) == '0') {
            		curr.left = child;
            		curr.right = null;
            	} else {
            		curr.right = child;
            		curr.left = null;
            	}
    			count++;
    			curr.isKey = true;
    			return true;
    		} 
    		
    		// insertion key and current node key share common prefix 
    		String pref = getSharedPrefix(key, curr.str);
    		
    		key = key.substring(pref.length());
    		String old_split_key = curr.str.substring(pref.length());
    		TrieNode new_key_node = new TrieNode(key, true);
    		TrieNode old_split_node = new TrieNode(old_split_key, curr.isKey);
    		old_split_node.left = curr.left;
    		old_split_node.right = curr.right;
    		
    		curr.str = pref;
    		curr.isKey = false;
    		if (key.charAt(0) == '0') {
    			curr.left = new_key_node;
    			curr.right = old_split_node;
    		} else {
    			curr.right = new_key_node;
    			curr.left = old_split_node;
    		}
    		count++;	
    	}
    	
    	return true;
    	
    }
    
    private String getSharedPrefix(String a, String b) {
        int minLength = Math.min(a.length(), b.length());
        for (int i = 0; i < minLength; i++) {
            if (a.charAt(i) != b.charAt(i)) {
                return a.substring(0, i);
            }
        }
        return a.substring(0, minLength);
    }


    /**
     * Deletes key from the trie.
     *
     * @param key The {@link String}  key to be deleted.
     * @return {@code true} if and only if key was contained by the trie before we attempted deletion, {@code false} otherwise.
     */
    // im pretty sure you dont have to worry about anything other than the parent
    public boolean delete(String key) {
    	TrieNode curr = root;
    	TrieNode parent = null;
    	// search through it
    	while (curr != null) {
    		if (key.length() >= curr.str.length() && key.substring(0,curr.str.length()).equals(curr.str)) {
    			key = key.substring(curr.str.length());
    		} else {
    			return false;
    		}
    		
    		if (key.isEmpty()) {
    			if (curr.isKey) {
    				break;
    			} else {
    				return false;
    			}
    		}
    		
    		parent = curr;
    		if (key.charAt(0) == '0') {
        		curr = curr.left;
        	} else {
        		curr = curr.right;
        	}
    		
    	}
    	
    	if (curr == null) {
    		return false;
    	}
    	
    	// if no children
    	if (curr.left == null && curr.right == null) {
    		if (curr.str.charAt(0) == '0') {
    			parent.left = null;
    		} else {
    			parent.right = null;
    		}
    		
    		// check if parent can be merged again
        	// am i allowed to just set current to parent and then do the next check case?
        	//curr = parent;
    		if (!parent.isKey && !parent.str.equals("")) {
    			curr = parent;
    		}
    	}
    	
    	// if has one child, so we merge
    	if (curr.left == null && curr.right != null) {
    		curr.str = curr.str + curr.right.str;
    		curr.isKey = curr.right.isKey;
    		TrieNode new_right = curr.right.right;
    		TrieNode new_left = curr.right.left;
    		curr.right = new_right;
    		curr.left = new_left;
    		
    	} else if (curr.right == null && curr.left != null) {
    		curr.str = curr.str + curr.left.str;
    		curr.isKey = curr.left.isKey;
    		TrieNode new_right = curr.left.right;
    		TrieNode new_left = curr.left.left;
    		curr.right = new_right;
    		curr.left = new_left;
      	}
    	// if current node has 2 children
    	else if (curr.left != null && curr.right != null) {
    		curr.isKey = false;
    	}
    	
    	count--;
    	return true;
    	
    }

    /**
     * Queries the trie for emptiness.
     *
     * @return {@code true} if and only if {@link #getSize()} == 0, {@code false} otherwise.
     */
    public boolean isEmpty() {
    	return getSize() == 0;
    }

    /**
     * Returns the number of keys in the tree.
     *
     * @return The number of keys in the tree.
     */
    public int getSize() {
    	return count;
    }

    /**
     * <p>Performs an <i>inorder (symmetric) traversal</i> of the Binary Patricia Trie. Remember from lecture that inorder
     * traversal in tries is NOT sorted traversal, unless all the stored keys have the same length. This
     * is of course not required by your implementation, so you should make sure that in your tests you
     * are not expecting this method to return keys in lexicographic order. We put this method in the
     * interface because it helps us test your submission thoroughly and it helps you debug your code! </p>
     *
     * <p>We <b>neither require nor test </b> whether the {@link Iterator} returned by this method is fail-safe or fail-fast.
     * This means that you  do <b>not</b> need to test for thrown {@link java.util.ConcurrentModificationException}s and we do
     * <b>not</b> test your code for the possible occurrence of concurrent modifications.</p>
     *
     * <p>We also assume that the {@link Iterator} is <em>immutable</em>, i,e we do <b>not</b> test for the behavior
     * of {@link Iterator#remove()}. You can handle it any way you want for your own application, yet <b>we</b> will
     * <b>not</b> test for it.</p>
     *
     * @return An {@link Iterator} over the {@link String} keys stored in the trie, exposing the elements in <i>symmetric
     * order</i>.
     */
    public Iterator<String> inorderTraversal() {
    	ArrayList<String> list = new ArrayList<>();
    	
    	traversalAux(list, root.str, root);
    	
		return new Iterator<String>() {
			int index = 0;
			
			@Override
			public boolean hasNext() {
				return index < list.size();
			}

			@Override
			public String next() {
				if (hasNext())	{
	                String str = list.get(index);
	                index++;
	                return str;
	            }
				else {
					return null;
				}
			}
		};
    	
    	
    }
    
    private void traversalAux(ArrayList<String> list, String str, TrieNode node) {
    	if (node == null) {
    		return;
    	}
    	
    	traversalAux(list, str + node.str, node.left);
    	
    	if (node.isKey) {
    		list.add(str + node.str);
    	}
    	
    	traversalAux(list, str + node.str, node.right);
    }

    /**
     * Finds the longest {@link String} stored in the Binary Patricia Trie.
     * @return <p>The longest {@link String} stored in this. If the trie is empty, the empty string &quot;&quot; should be
     * returned. Careful: the empty string &quot;&quot;is <b>not</b> the same string as &quot; &quot;; the latter is a string
     * consisting of a single <b>space character</b>! It is also <b>not the same as the</b> null <b>reference</b>!</p>
     *
     * <p>Ties should be broken in terms of <b>value</b> of the bit string. For example, if our trie contained
     * only the binary strings 01 and 11, <b>11</b> would be the longest string. If our trie contained
     * only 001 and 010, <b>010</b> would be the longest string.</p>
     */
    
    // compare strings at leaf nodes
    public String getLongest() {
    	ArrayList<String> list = new ArrayList<>();
    	getLongestAux(list, root.str, root);
    	
    	String longest = list.get(0);
    	for (String s : list) {
    		if (s.length() > longest.length() || (s.length() == longest.length() && Integer.parseInt("0"+s, 2) > Integer.parseInt("0"+longest, 2))) {
    			longest = s;
    		}
    	}
    	
    	return longest;
    	
    }
    
    private void getLongestAux(ArrayList<String> list, String str, TrieNode node) {
    	if (node == null) {
    		return;
    	}
    	
    	getLongestAux(list, str + node.str, node.left);
    	getLongestAux(list, str + node.str, node.right);

    	
    	if (node.left == null && node.right == null) {
    		list.add(str + node.str);
    	}
    	
    }

    /**
     * Makes sure that your trie doesn't have splitter nodes with a single child. In a Patricia trie, those nodes should
     * be pruned.
     * @return {@code true} iff all nodes in the trie either denote stored strings or split into two subtrees, {@code false} otherwise.
     */
    public boolean isJunkFree(){
        return isEmpty() || (isJunkFree(root.left) && isJunkFree(root.right));
    }

    private boolean isJunkFree(TrieNode n){
        if(n == null){   // Null subtrees trivially junk-free
            return true;
        }
        if(!n.isKey){   // Non-key nodes need to be strict splitter nodes
            return ( (n.left != null) && (n.right != null) && isJunkFree(n.left) && isJunkFree(n.right) );
        } else {
            return ( isJunkFree(n.left) && isJunkFree(n.right) ); // But key-containing nodes need not.
        }
    }
    /*
	public void printNode() {
	    int maxLevel = maxLevel(root);
	
	    printNodeInternal(Collections.singletonList(root), 1, maxLevel);
	}
	
	private void printNodeInternal(List<TrieNode> nodes, int level, int maxLevel) {
	    if (nodes.isEmpty() || isAllElementsNull(nodes))
	        return;
	
	    int floor = maxLevel - level;
	    int endgeLines = (int) Math.pow(2, (Math.max(floor - 1, 0)));
	    int firstSpaces = (int) Math.pow(2, (floor)) - 1;
	    int betweenSpaces = (int) Math.pow(2, (floor + 1)) - 1;
	
	    printWhitespaces(firstSpaces);
	
	    List<TrieNode> newNodes = new ArrayList<TrieNode>();
	    for (TrieNode node : nodes) {
	        if (node != null) {
	            System.out.print(node.str);
	            if (node.isKey)	
	            	System.out.print("*");
	            newNodes.add(node.left);
	            newNodes.add(node.right);
	        } else {
	            newNodes.add(null);
	            newNodes.add(null);
	            System.out.print(" ");
	        }
	
	        printWhitespaces(betweenSpaces);
	    }
	    System.out.println("");
	
	    for (int i = 1; i <= endgeLines; i++) {
	        for (int j = 0; j < nodes.size(); j++) {
	            printWhitespaces(firstSpaces - i);
	            if (nodes.get(j) == null) {
	                printWhitespaces(endgeLines + endgeLines + i + 1);
	                continue;
	            }
	
	            if (nodes.get(j).left != null)
	                System.out.print("/");
	            else
	                printWhitespaces(1);
	
	            printWhitespaces(i + i - 1);
	
	            if (nodes.get(j).right != null)
	                System.out.print("\\");
	            else
	                printWhitespaces(1);
	
	            printWhitespaces(endgeLines + endgeLines - i);
	        }
	
	        System.out.println("");
	    }
	
	    printNodeInternal(newNodes, level + 1, maxLevel);
	}
	
	private void printWhitespaces(int count) {
	    for (int i = 0; i < count; i++)
	        System.out.print(" ");
	}
	
	private int maxLevel(TrieNode node) {
	    if (node == null)
	        return 0;
	
	    return Math.max(maxLevel(node.left), maxLevel(node.right)) + 1;
	}
	
	private boolean isAllElementsNull(List<TrieNode> list) {
	    for (Object object : list) {
	        if (object != null)
	            return false;
	    }
	
	    return true;
	} */
}
