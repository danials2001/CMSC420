package phonebook.hashes;

import phonebook.exceptions.UnimplementedMethodException;
import phonebook.utils.KVPair;
import phonebook.utils.PrimeGenerator;
import phonebook.utils.Probes;

/**
 * <p>{@link OrderedLinearProbingHashTable} is an Openly Addressed {@link HashTable} implemented with
 * <b>Ordered Linear Probing</b> as its collision resolution strategy: every key collision is resolved by moving
 * one address over, and the keys in the chain is in order. It suffer from the &quot; clustering &quot; problem:
 * collision resolutions tend to cluster collision chains locally, making it hard for new keys to be
 * inserted without collisions. {@link QuadraticProbingHashTable} is a {@link HashTable} that
 * tries to avoid this problem, albeit sacrificing cache locality.</p>
 *
 * @author YOUR NAME HERE!
 *
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see LinearProbingHashTable
 * @see QuadraticProbingHashTable
 * @see CollisionResolver
 */
public class OrderedLinearProbingHashTable extends OpenAddressingHashTable {

    /* ********************************************************************/
    /* ** INSERT ANY PRIVATE METHODS OR FIELDS YOU WANT TO USE HERE: ******/
    /* ********************************************************************/
	private int tombstoneCount = 0;

    /* ******************************************/
    /*  IMPLEMENT THE FOLLOWING PUBLIC METHODS: */
    /* **************************************** */

    /**
     * Constructor with soft deletion option. Initializes the internal storage with a size equal to the starting value of  {@link PrimeGenerator}.
     * @param soft A boolean indicator of whether we want to use soft deletion or not. {@code true} if and only if
     *               we want soft deletion, {@code false} otherwise.
     */
    public OrderedLinearProbingHashTable(boolean soft){
    	softFlag = soft;
    	primeGenerator = new PrimeGenerator();
    	table = new KVPair[primeGenerator.getCurrPrime()];
    }



    /**
     * Inserts the pair &lt;key, value&gt; into this. The container should <b>not</b> allow for {@code null}
     * keys and values, and we <b>will</b> test if you are throwing a {@link IllegalArgumentException} from your code
     * if this method is given {@code null} arguments! It is important that we establish that no {@code null} entries
     * can exist in our database because the semantics of {@link #get(String)} and {@link #remove(String)} are that they
     * return {@code null} if, and only if, their key parameter is {@code null}. This method is expected to run in <em>amortized
     * constant time</em>.
     *
     * Different from {@link LinearProbingHashTable}, the keys in the chain are <b>in order</b>. As a result, we might increase
     * the cost of insertion and reduce the cost on search miss. One thing to notice is that, in soft deletion, we ignore
     * the tombstone during the reordering of the keys in the chain. We will have some example in the writeup.
     *
     * Instances of {@link OrderedLinearProbingHashTable} will follow the writeup's guidelines about how to internally resize
     * the hash table when the capacity exceeds 50&#37;
     * @param key The record's key.
     * @param value The record's value.
     * @throws IllegalArgumentException if either argument is {@code null}.
     * @return The {@link phonebook.utils.Probes} with the value added and the number of probes it makes.
     */
    @Override
    public Probes put(String key, String value) {
    	if (key == null || value == null) {
    		throw new IllegalArgumentException("null key and/or value");
    	}
    	
    	int probes = 0;
    	
    	// resize
    	if ((double)(count + tombstoneCount)/capacity() > .5) {
    		int new_capacity = primeGenerator.getNextPrime();
    		KVPair[] old_table = table;
    		table = new KVPair[new_capacity];
    		for (KVPair kv : old_table) {
    			probes++;
    			// reinsert all nodes in old table
    			if (kv != null && !kv.equals(TOMBSTONE)) {
    				int hash = hash(kv.getKey());
    				while (table[hash % new_capacity] != null) {
    					if (kv.getKey().compareTo(table[hash % new_capacity].getKey()) < 0) {
    						KVPair temp = table[hash % new_capacity];
    						table[hash%new_capacity] = kv;
    						kv = temp;
    					}
    					hash++;
    					probes++;
    				}
    				probes++;
    				table[hash%new_capacity] = kv;
    			}
    		}
        	tombstoneCount = 0;
    	}
    	
    	// insert new node
    	KVPair toInsert = new KVPair(key, value);
    	int hash = hash(key);
    	while (table[hash % capacity()] != null/* && !table[hash%capacity()].equals(TOMBSTONE)*/) {
    		if (toInsert.getKey().compareTo(table[hash % capacity()].getKey()) < 0) {
				KVPair temp = table[hash % capacity()];
				table[hash%capacity()] = toInsert;
				toInsert = temp;
			}
    		probes++;
    		hash++;
    	}
    	/*
    	if (table[hash%capacity()] != null && table[hash%capacity()].equals(TOMBSTONE)) {
    		tombstoneCount--;
    	} */
    	table[hash%capacity()] = toInsert;
    	probes++;
    	count++;
    	
    	return new Probes(value, probes);
    }

    @Override
    public Probes get(String key) {
    	if (key == null) {
    		return new Probes(null, 0);
    	}
    	
    	int probes = 1;
    	int hash = hash(key);
    	Probes p = null;
    	
    	while (table[hash%capacity()] != null) {
    		if (table[hash%capacity()].getKey().equals(key)) {
    			p = new Probes(table[hash%capacity()].getValue(), probes);
    	    	//if (key.equals("Yi"))
    	    	//	System.out.println("OLP: " + key + ", " + table[hash%capacity()].getValue() + " found at " + hash%capacity());
    			break;
    		}
    		probes++;
    		hash++;
    	}
    	
    	if (p == null) {
    		return new Probes(null, probes);
    	}
    	return p;
    }


    /**
     * <b>Return</b> the value associated with key in the {@link HashTable}, and <b>remove</b> the {@link phonebook.utils.KVPair} from the table.
     * If key does not exist in the database
     * or if key = {@code null}, this method returns {@code null}. This method is expected to run in <em>amortized constant time</em>.
     *
     * @param key The key to search for.
     * @return The {@link phonebook.utils.Probes} with associated value and the number of probe used. If the key is {@code null}, return value {@code null}
     * and 0 as number of probes; if the key doesn't exist in the database, return {@code null} and the number of probes used.
     */
    @Override
    public Probes remove(String key) {
    	// first step for both hard and soft is to find kv, iterate through till found (or null reached)
    	int probes = 1;
    	int hash = hash(key);
    	String value = null;
    	
    	while (table[hash%capacity()] != null) {
    		if (table[hash%capacity()].getKey().equals(key)) {
    			value = table[hash%capacity()].getValue();
    			// if soft we can just make it a tombstone
    			if (softFlag) {
    				tombstoneCount++;
    				count--;
    				table[hash%capacity()] = TOMBSTONE;
    				return new Probes(value, probes);
    			}
    			
    			// hard delete value
    	    	table[hash%capacity()] = null;
    	    	count--;
    	    	hash++;
    	    	
    	    	// hard deletion reinserting till end of cluster
    	    	// hash is index of the start of the cluster
    	    	// reinserting is running into problems, we have to actually delete the values we are trying to reinsert
    	    	while (table[hash % capacity()] != null) {
    	    		probes++;
    	    		
    	    		KVPair kv = table[hash%capacity()];
    	    		table[hash%capacity()] = null;
    	    		int new_hash = hash(kv.getKey());
    	    		while (table[new_hash % capacity()] != null) {
    	    			if (kv.getKey().compareTo(table[new_hash % capacity()].getKey()) < 0) {
    	    				KVPair temp = table[new_hash % capacity()];
    	    				table[new_hash%capacity()] = kv;
    	    				kv = temp;
    	    			}
    	    			new_hash++;
    	    			probes++;
    	    		}
    	    		//TODO
    	    		probes++;
    	    		table[new_hash%capacity()] = kv;
    	    		
    	    		hash++;
    	    	}
    	    	probes++;
    	    	return new Probes(value, probes);
    		}
    		probes++;
    		hash++;
    	}
    	return new Probes(null, probes);
    	
    	
    }
/*    
    public Probes remove(String key) {
    	// first step for both hard and soft is to find kv, iterate through till found (or null reached)
    	int probes = 1;
    	int hash = hash(key);
    	boolean found = false;
    	String value = null;
    	
    	while (table[hash%capacity()] != null) {
    		if (table[hash%capacity()].getKey().equals(key)) {
    			value = table[hash%capacity()].getValue();
    			found = true;
    			// if soft we can just make it a tombstone here
    			if (softFlag) {
    				tombstoneCount++;
    				count--;
    				table[hash%capacity()] = TOMBSTONE;
    				return new Probes(value, probes);
    			}
    			break;
    		}
    		probes++;
    		hash++;
    	}
    	if (!found) {
    		return new Probes(null, probes);
    	}
    	
    	// hard delete value
    	table[hash%capacity()] = null;
    	count--;
    	hash++;
    	probes++;
    	
    	// hard deletion reinserting till end of cluster
    	// hash is index of the start of the cluster
    	while (table[hash % capacity()] != null) {
    		probes++;
    		
    		KVPair kv = table[hash%capacity()];
    		table[hash%capacity()] = null;
    		int new_hash = hash(kv.getKey());
    		while (table[new_hash % capacity()] != null) {
    			if (hash(kv.getKey()) < hash(table[new_hash % capacity()].getKey())) {
    				KVPair temp = table[new_hash % capacity()];
    				table[new_hash%capacity()] = kv;
    				kv = temp;
    			}
    			new_hash++;
    			probes++;
    		}
    		table[new_hash%capacity()] = kv;
    		
    		hash++;
    	}
    	
    	return new Probes(value, probes);
    }
*/
    
    @Override
    public boolean containsKey(String key) {
    	int hash = hash(key);
    	
    	while (table[hash % capacity()] != null) {
    		if (table[hash % capacity()].getKey().equals(key)) {
    			return true;
    		}
    		hash++;
    	}
    	return false;
    }

    @Override
    public boolean containsValue(String value) {
    	for (KVPair kv : table) {
    		if (kv != null && kv.getValue().equals(value)) {
    			return true;
    		}
    	}
    	return false;
    }

    @Override
    public int size() {
    	return count;
    }

    @Override
    public int capacity() {
    	return table.length;
    }

}
