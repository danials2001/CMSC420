package pqueue.heaps; // ******* <---  DO NOT ERASE THIS LINE!!!! *******

/* *****************************************************************************************
 * THE FOLLOWING IMPORT IS NECESSARY FOR THE ITERATOR() METHOD'S SIGNATURE. FOR THIS
 * REASON, YOU SHOULD NOT ERASE IT! YOUR CODE WILL BE UNCOMPILABLE IF YOU DO!
 * ********************************************************************************** */

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Collections;


/**
 * <p>{@link ArrayMinHeap} is a {@link MinHeap} implemented using an internal array. Since heaps are <b>complete</b>
 * binary trees, using contiguous storage to store them is an excellent idea, since with such storage we avoid
 * wasting bytes per {@code null} pointer in a linked implementation.</p>
 *
 * <p>You <b>must</b> edit this class! To receive <b>any</b> credit for the unit tests related to this class,
 * your implementation <b>must</b> be a <b>contiguous storage</b> implementation based on a linear {@link java.util.Collection}
 * like an {@link java.util.ArrayList} or a {@link java.util.Vector} (but *not* a {@link java.util.LinkedList} because it's *not*
 * contiguous storage!). or a raw Java array. We provide an array for you to start with, but if you prefer, you can switch it to a
 * {@link java.util.Collection} as mentioned above. </p>
 *
 * @author -- YOUR NAME HERE ---
 *
 * @see MinHeap
 * @see LinkedMinHeap
 * @see demos.GenericArrays
 */

public class ArrayMinHeap<T extends Comparable<T>> implements MinHeap<T> {

	/* *****************************************************************************************************************
	 * This array will store your data. You may replace it with a linear Collection if you wish, but
	 * consult this class' 	 * JavaDocs before you do so. We allow you this option because if you aren't
	 * careful, you can end up having ClassCastExceptions thrown at you if you work with a raw array of Objects.
	 * See, the type T that this class contains needs to be Comparable with other types T, but Objects are at the top
	 * of the class hierarchy; they can't be Comparable, Iterable, Clonable, Serializable, etc. See GenericArrays.java
	 * under the package demos* for more information.
	 * *****************************************************************************************************************/
	//private Object[] data;
	private ArrayList<T> data;

	
	/* *********************************************************************************** *
	 * Write any further private data elements or private methods for LinkedMinHeap here...*
	 * *************************************************************************************/
	private int lastIndex; // Holds the index of the last element in the array.
	protected boolean modificationFlag; 

	private void swapElements(int index1, int index2) {
		T temp = data.get(index1);
		data.set(index1, data.get(index2));
		data.set(index2, temp);
	}

	/* *********************************************************************************************************
	 * Implement the following public methods. You should erase the throwings of UnimplementedMethodExceptions.*
	 ***********************************************************************************************************/

	/**
	 * Default constructor initializes the data structure with some default
	 * capacity you can choose.
	 */
	public ArrayMinHeap(){
		data = new ArrayList<>();
		lastIndex = -1;
		modificationFlag = false;
	}

	/**
	 *  Second, non-default constructor which provides the element with which to initialize the heap's root.
	 *  @param rootElement the element to create the root with.
	 */
	public ArrayMinHeap(T rootElement){
		data = new ArrayList<>();
		data.add(rootElement);
		lastIndex++;
		modificationFlag = true;
	}

	/**
	 * Copy constructor initializes {@code this} as a carbon copy of the {@link MinHeap} parameter.
	 *
	 * @param other The MinHeap object to base construction of the current object on.
	 */
	// ITERATE THROUGH other HEAP AND INITIALIZE NEW data WITH ELEMENTS IN ORDER
	public ArrayMinHeap(MinHeap<T> other){
		this();
		Iterator<T> it = other.iterator();
		while (it.hasNext()) {
			insert(it.next());
		}
	}

	/**
	 * Standard {@code equals()} method. We provide it for you: DO NOT ERASE! Consider its implementation when implementing
	 * {@link #ArrayMinHeap(MinHeap)}.
	 * @return {@code true} if the current object and the parameter object
	 * are equal, with the code providing the equality contract.
	 * @see #ArrayMinHeap(MinHeap)
	 */
	@Override
	public boolean equals(Object other){
		if(other == null || !(other instanceof MinHeap))
			return false;
		Iterator itThis = iterator();
		Iterator itOther = ((MinHeap) other).iterator();
		while(itThis.hasNext())
			if(!itThis.next().equals(itOther.next()))
				return false;
		return !itOther.hasNext();
	}


	@Override
	public void insert(T element) {
		data.add(element);
		lastIndex++;
		int i = lastIndex;
		while (i > 0 && data.get(i).compareTo(data.get((int) Math.floor((double)(i-1)/2))) <= 0) {
			int parent = (int) Math.floor((double)(i-1)/2);
			swapElements(i, parent);
			i = parent;
		}
		modificationFlag = true;
	}

	@Override
	public T deleteMin() throws EmptyHeapException { // DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (isEmpty()) {
			throw new EmptyHeapException("Deleting from Empty Heap");
		}
		T ret = getMin();
		if (size() == 1) {
			data.remove(0);
			lastIndex--;
			return ret;
		}
		data.set(0, data.remove(lastIndex));
		lastIndex--;
		// percolate down
		if (size() > 1) {
			int i = 0;
			// maybe this doesnt work if only has one child?
			while ((2*i+1 < data.size() && (data.get(i).compareTo(data.get(2*i + 1)) > 0) || 2*i+2 < data.size() && data.get(i).compareTo(data.get(2*i + 2)) > 0)) {
				int child = 2*i;
				// left side is smaller
				if (2*i+2 >= data.size() || data.get(2*i + 1).compareTo(data.get(2*i + 2)) < 0) {
					child += 1;
				} else {
					child += 2;
				}
				swapElements(i, child);
				i = child;
			}
		}
		modificationFlag = true;
		return ret;
	}

		@Override
	public T getMin() throws EmptyHeapException {	// DO *NOT* ERASE THE "THROWS" DECLARATION!
		if (size() > 0) {
			return data.get(0);
		}
		throw new EmptyHeapException("Min does not exist in Empty Heap");
	}

	@Override
	public int size() {
		return lastIndex+1;
	}

	@Override
	public boolean isEmpty() {
		return size() > 0 ? false : true;
	}

	/**
	 * Standard equals() method.
	 * @return {@code true} if the current object and the parameter object
	 * are equal, with the code providing the equality contract.
	 */

	//NOT IN ASCENDING ORDER
	@Override
	public Iterator<T> iterator() {
		modificationFlag = false;
		ArrayList<T> store = data;
		Collections.sort(store);
		Iterator<T> it = new Iterator<T>() {

			private int currentIndex = 0;
			

            @Override
            public boolean hasNext() {
            	return currentIndex < data.size() && data.get(currentIndex) != null;
            }

            @Override
            public T next() {
            	if(modificationFlag)
    				throw new ConcurrentModificationException("next(): Attempted to traverse a list after removal.");
    			return  store.get(currentIndex++);
            }

        };
        return it;	}

}
