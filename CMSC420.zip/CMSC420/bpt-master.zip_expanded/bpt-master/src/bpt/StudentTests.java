package bpt;
import org.junit.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

/**
 * A jUnit test suite for {@link BinaryPatriciaTrie}.
 *
 * @author --- YOUR NAME HERE! ----.
 */
public class StudentTests {

	public String randomBitString(int max) {
        int targetStringLength = (int)Math.floor(Math.random()*(max-1+1)+1);
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            char c;
        	if (random.nextBoolean()) {
            	c = '1';
            } else {
            	c = '0';
            }
            buffer.append(c);
        }
        String generatedString = buffer.toString();

        return generatedString;
    }
	
	public ArrayList<String> uniqueRandArrBuilder(int arrLength, int maxStringLength) {
		Set<String> set = new HashSet<>();
		
		while (set.size() < arrLength) {
			set.add(randomBitString(maxStringLength));
		}

		ArrayList<String> arr = new ArrayList<String>(set);
		return arr;
	}
	
    @Test public void testEmptyTrie() {
        BinaryPatriciaTrie trie = new BinaryPatriciaTrie();

        assertTrue("Trie should be empty",trie.isEmpty());
        assertEquals("Trie size should be 0", 0, trie.getSize());

        assertFalse("No string inserted so search should fail", trie.search("0101"));

    }

    @Test public void testFewInsertionsWithSearch() {
        BinaryPatriciaTrie trie = new BinaryPatriciaTrie();

        assertTrue("String should be inserted successfully",trie.insert("00000"));
        assertTrue("String should be inserted successfully",trie.insert("00011"));
        assertFalse("Search should fail as string does not exist",trie.search("000"));

    }


    //testing isEmpty function
    @Test public void testFewInsertionsWithDeletion() {
        BinaryPatriciaTrie trie = new BinaryPatriciaTrie();

        trie.insert("000");
        trie.insert("001");
        trie.insert("011");
        trie.insert("1001");
        trie.insert("1");
        
        Iterator<String> iter = trie.inorderTraversal();
        while (iter.hasNext()) {
        	System.out.println(iter.next() + "");
        }
        
        //trie.printNode();

        assertFalse("After inserting five strings, the trie should not be considered empty!", trie.isEmpty());
        assertEquals("After inserting five strings, the trie should report five strings stored.", 5, trie.getSize());

        trie.delete("0"); // Failed deletion; should affect exactly nothing.
        assertEquals("After inserting five strings and requesting the deletion of one not in the trie, the trie " +
                "should report five strings stored.", 5, trie.getSize());
        assertTrue("After inserting five strings and requesting the deletion of one not in the trie, the trie had some junk in it!",
                trie.isJunkFree());

        trie.delete("011"); // Successful deletion
        assertEquals("After inserting five strings and deleting one of them, the trie should report 4 strings.", 4, trie.getSize());
        assertTrue("After inserting five strings and deleting one of them, the trie had some junk in it!",
                trie.isJunkFree());
    }
    
    
    @Test
    public void test2() {
        BinaryPatriciaTrie trie = new BinaryPatriciaTrie();
    	
    	ArrayList<String> toAdd = uniqueRandArrBuilder(20, 8);
    	ArrayList<String> added = new ArrayList<>();
    	ArrayList<String> removed = new ArrayList<>();
    	
    	
    	int i = 1;
    	for (String s : toAdd) {
    		assertTrue("string not found in trie", trie.insert(s));
    		added.add(s);
    		System.out.println("--------------------");
    		System.out.println(i + ") Inserting " + s);
    		//trie.printNode();
    		i++;
    	}
    	
    	System.out.println("ADDED COUNT: " + added.size());
    	System.out.println("KEYS COUNT: " + trie.getSize());

    	
    	Collections.shuffle(added);
    	int addedsize = added.size();
    	for (int j = 0; j < addedsize; j++) {
        	String key =  added.get(0);
    		System.out.println("--------------------");
            System.out.println(i + ") Deleting " + key);
            added.remove(key);
            removed.add(key);
            assertTrue("string not found in trie", trie.delete(key));
    		//trie.printNode();
    		assertFalse("deleted node found in array", trie.search(key));
    		i++;
    	}
    	
    	System.out.println("REMOVED COUNT: " + added.size());
    	System.out.println("KEYS COUNT: " + trie.getSize());


    }
    
    @Test
    public void testLongest() {
        BinaryPatriciaTrie trie = new BinaryPatriciaTrie();
        assertEquals("", trie.getLongest());
    
    }
}